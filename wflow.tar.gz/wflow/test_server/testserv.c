/*TEST SERVER CODE */
/*Fleming 
Test code for smart water managment project
########
##
##
#######
##fleming embedded solution
##Athul
##
##


*/
#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#define PORT (7777)
#define IP ("127.0.0.1")
#define DEVICE_ID (0x07)

int main(){
				int flemingwelcomeSocket, newSocket,ret;
				char buffer[128],ch;
				struct sockaddr_in serverAddr;
				struct sockaddr_storage serverStorage;
				socklen_t addr_size;
				flemingwelcomeSocket = socket(PF_INET, SOCK_STREAM, 0);
				serverAddr.sin_family = AF_INET;
				serverAddr.sin_port = htons(PORT);
				serverAddr.sin_addr.s_addr = inet_addr(IP);
				memset(serverAddr.sin_zero, '\0', sizeof serverAddr.sin_zero);  
				bind(flemingwelcomeSocket, (struct sockaddr *) &serverAddr, sizeof(serverAddr));
				if(listen(flemingwelcomeSocket,5)==0)
								printf("Listening\n");
				else
								perror("Error:Listening\n");

				addr_size = sizeof serverStorage;
				newSocket = accept(flemingwelcomeSocket, (struct sockaddr *) &serverStorage, &addr_size);
				while(1){
						ret=recv(newSocket,buffer,10,0);
						if (ret<0){
										perror("Recv:");
						}
						printf("Got overflowdata=%d from %x device\r\n",buffer[0],buffer[1]);
						printf("Force close valve?(y/n)\r\n");	
//						ch=getchar();
						scanf(" %c",&ch);
						if(ch=='y'){

								if(send(newSocket,buffer,13,0)<0){
												perror("send:");
								}else{
												printf("Send success\r\n");
								}
						}
						else{
										printf("Not replying\r\n");
						}

						}

			

				return 0;
}
