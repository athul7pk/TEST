/*
########
##
##
#######
##fleming embedded solution
##Athul
##
##
*/



#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
/*Macros*/
#define PORT (7777)
#define IP ("127.0.0.1")
#define DeviceID (0x07)
#define MIN_THRESHOLD (2)
#define MAX_THRESHOLD (10)
/*Globals*/

int clientSocket,adc;
char buffer[128];
struct sockaddr_in serverAddr;
int rc=0;
pthread_t tid;


/*Function used for polling message from server*/

void poll_message_from_server(){
				while(1){
								rc=recv(clientSocket, buffer, 1024, 0);
								if(rc<=0){
												perror("Recv:");
												exit(-1);

								}
								else{
												printf("Message recieved from server for device= %x: message=%x\r\n",buffer[0],buffer[1]);								
												if(buffer[1]==1){
																printf("closing valve\r\n"); /*TBD: close using gpio*/
												}


								}
				}

}



int main(){
				socklen_t addr_size;
				clientSocket = socket(PF_INET, SOCK_STREAM, 0);
				serverAddr.sin_family = AF_INET;
				serverAddr.sin_port = htons(PORT);
				serverAddr.sin_addr.s_addr = inet_addr(IP);
				/*TBD:
					init gpios
					init mcp3008
					configure adc channels
					incoperate pirsensor

				 */





				memset(serverAddr.sin_zero, '\0', sizeof serverAddr.sin_zero);  
				addr_size = sizeof serverAddr;

				rc=connect(clientSocket, (struct sockaddr *) &serverAddr, addr_size);
				if(rc<0){
								perror("Server connect error:");
								exit(-1);
				}
				pthread_create(&tid,NULL,poll_message_from_server,NULL);		
				while(1){
								printf("Enter adc value\r\n");
								scanf("%d",&adc);/*TBD :Read actual adc*/

								if((adc>MIN_THRESHOLD)&&(adc<MAX_THRESHOLD)){
												buffer[0]=DeviceID;
												buffer[1]=1;
												rc=send(clientSocket, buffer,3, 0);
												if(rc<0){
																perror("Send:");
																exit(-1);
												}
												else{
																printf("data send to server success\r\n");
												}
								}
								else{
												printf("Normal Flow not sending to server\r\n");
								}
				}



				return 0;
}
