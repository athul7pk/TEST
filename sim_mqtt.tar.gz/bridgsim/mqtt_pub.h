#ifndef __MQTT_PUB_H 
#define  __MQTT_PUB_H 



int disconnect_mqtt_server();
int init_mqtt_connection( char *username, char*password);
int publish_mqtt_message(char*topic ,char *payload, int sz);


#endif
