#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "MQTTClient.h"
#include "mqtt_pub.h"
#define ADDRESS     "mqtt2.wisilica.com:8883"
#define CLIENTID    "26"
#define TOPIC       "tag/segment/data/+/22/23"

#define PAYLOAD     "Reshmi 155"
#define QOS         1
#define TIMEOUT     10000L




/*
Author:Reshmi R
Global variables
 */


MQTTClient client;
MQTTClient_connectOptions conn_opts = MQTTClient_connectOptions_initializer;
MQTTClient_message pubmsg = MQTTClient_message_initializer;
MQTTClient_deliveryToken token;

/*

Author:Reshmi R
Functioname: init_mqtt_connection
return: int ,status of init 0 success
param: char *username and char * password
 */


int init_mqtt_connection( char *username, char*password){
		int rc;
		MQTTClient_create(&client, ADDRESS, CLIENTID,
						MQTTCLIENT_PERSISTENCE_NONE, NULL);
		conn_opts.keepAliveInterval = 20;
		conn_opts.cleansession = 1;
		conn_opts.username=username;
		conn_opts.password=password;

		if ((rc = MQTTClient_connect(client, &conn_opts)) != MQTTCLIENT_SUCCESS)
		{
				printf("Failed to connect, return code %d\n", rc);
				return -1;
				exit(-1);

		}
		return 0;
}

/*

Author:Reshmi R
Function name : disconnect_mqtt_server
return : int,status 0 -success 
param:void
 */
int disconnect_mqtt_server(){
		MQTTClient_disconnect(client, 10000);
		MQTTClient_destroy(&client);
		return 0;
}
/*

Author:Reshmi R
Function name :  publish_mqtt_message
return : int,status 0 -success 
param:char *topic char, *payload
 */



int publish_mqtt_message(char*topic ,char *payload,int sz){

		int rc;
		pubmsg.payload = payload;
		pubmsg.payloadlen = sz;
		pubmsg.qos = QOS;
		pubmsg.retained = 0;
		MQTTClient_publishMessage(client, topic, &pubmsg, &token);
		printf("Waiting for up to %d seconds for publication of %s\n"
						"on topic %s for client with ClientID: %s\n",
						(int)(TIMEOUT/1000), PAYLOAD, TOPIC, CLIENTID);
		rc = MQTTClient_waitForCompletion(client, token, TIMEOUT);
		printf("Message with delivery token %d delivered\n", token);
		return rc;

}

#if 1
int main(){
		if (!init_mqtt_connection("a5e3b3837d32@a5e3b3837d32","a5e3b3837d32@123")){
				printf("Mqtt Connect Error To server\r\n");
		}
		else{
				printf("MQTT connect failed\r\n");
				exit(-1);
		}
		publish_mqtt_message(TOPIC,PAYLOAD,strlen(PAYLOAD));
		disconnect_mqtt_server();
}
#endif
